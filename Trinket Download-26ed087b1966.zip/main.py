print("FORMULA FOR PHYSICS (mechanics)")
frmla = input("Enter the term (in lowercase): ") 



if frmla == "work":
    print("fs (force * displacement)")
elif frmla == "force":
    print("ma (mass * acceleration)")
elif frmla == "power":
    print("w/t (work/time)")
elif frmla == "kinetic energy":
    print("1/2 mv^2 (1/2 * mass * velocity whole square)")
elif frmla == "potential energy":
    print("mgh (mass * gravity * height)")
elif frmla == "distance" or frmla == "displacement":
    print("vt (velocity * time)")
elif frmla == "velocity":
    print("u + at (initial velocity + acceleration * time)")
elif frmla == "velocity^2":
    print("u^2 + 2as (initial velocity whole square + 2 * acceleration * displacement)")
elif frmla == "acceleration": 
    print("(v - u) / (t - t0) (final velocity - initial velocity / final time - initial time)")
else:
    print("not a part of mechanics")
    


    

